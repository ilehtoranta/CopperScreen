param(
    [string]$Configuration = "Release",
    [int]$Warmup = 10000,
    [int]$Decisions = 100000,
    [int]$Repeats = 7
)

$ErrorActionPreference = "Stop"
$repoRoot = Split-Path -Parent $PSScriptRoot
$benchmarkProject = Join-Path $repoRoot "CopperScreen.Benchmarks\CopperScreen.Benchmarks.csproj"
$previousTieredCompilation =
    [Environment]::GetEnvironmentVariable(
        "DOTNET_TieredCompilation",
        [EnvironmentVariableTarget]::Process)

try {
    $env:DOTNET_TieredCompilation = "0"
    $output = & dotnet run `
        --project $benchmarkProject `
        -c $Configuration `
        --no-restore `
        -- `
        --agnus-live-blitter-slot-benchmark `
        --warmup $Warmup `
        --decisions $Decisions `
        --repeats $Repeats
    $output | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw "G3L blitter benchmark failed with exit code $LASTEXITCODE."
    }

    $repeatLines = @(
        $output |
            Where-Object { $_ -match "^[0-9]+\t" }
    )
    if ($repeatLines.Count -ne $Repeats) {
        throw "Expected $Repeats benchmark repeat rows, found $($repeatLines.Count)."
    }

    foreach ($line in $repeatLines) {
        $columns = $line -split "`t"
        if ($columns.Count -lt 15) {
            throw "Malformed G3L benchmark row '$line'."
        }

        if ([long]$columns[5] -ne 0 -or
            [long]$columns[6] -ne 0 -or
            [long]$columns[11] -ne 0 -or
            [long]$columns[12] -ne 0) {
            throw "G3L exact-slot benchmark allocated in steady state: '$line'."
        }
    }

    $medianLine = $output |
        Where-Object { $_ -match "^median\t" } |
        Select-Object -Last 1
    if (-not $medianLine) {
        throw "G3L blitter benchmark did not publish a median row."
    }

    $median = $medianLine -split "`t"
    $culture = [System.Globalization.CultureInfo]::InvariantCulture
    $searchGrant = [double]::Parse($median[1], $culture)
    $exactGrant = [double]::Parse($median[2], $culture)
    $exactDenied = [double]::Parse($median[3], $culture)
    $nastyPending = [double]::Parse($median[5], $culture)
    $niceContention = [double]::Parse($median[6], $culture)
    $maximum = $searchGrant * 1.05
    if ($exactGrant -gt $maximum) {
        throw "Exact granted-slot median $exactGrant ns exceeds 105% of searching grant $searchGrant ns."
    }

    if ($exactDenied -gt $maximum) {
        throw "Exact denied-slot median $exactDenied ns exceeds 105% of searching grant $searchGrant ns."
    }

    $contentionMaximum = $searchGrant * 1.15
    if ($nastyPending -gt $contentionMaximum) {
        throw "BLTPRI pending-CPU median $nastyPending ns exceeds 115% of searching grant $searchGrant ns."
    }

    if ($niceContention -gt $contentionMaximum) {
        throw "Nice blitter/CPU contention median $niceContention ns exceeds 115% of searching grant $searchGrant ns."
    }

    Write-Host "G3L live blitter exact-slot performance PASS"
    Write-Host "search_grant_median_ns=$searchGrant"
    Write-Host "exact_grant_median_ns=$exactGrant"
    Write-Host "exact_denied_median_ns=$exactDenied"
    Write-Host "nasty_pending_median_ns=$nastyPending"
    Write-Host "nice_contention_median_ns=$niceContention"
}
finally {
    if ($null -eq $previousTieredCompilation) {
        Remove-Item Env:DOTNET_TieredCompilation -ErrorAction SilentlyContinue
    }
    else {
        $env:DOTNET_TieredCompilation = $previousTieredCompilation
    }
}

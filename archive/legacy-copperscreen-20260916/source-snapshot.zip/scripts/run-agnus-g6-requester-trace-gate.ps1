param(
    [string]$Configuration = "Release",
    [string]$Workload = "Lemmings SR",
    [string]$Profile = "expanded-kickstart13.json",
    [string]$KickstartRom = "D:\TestData\ROM\Kickstart_13.rom",
    [switch]$SkipBuild,
    [string]$BenchmarkAssemblyPath,
    [string]$EvidenceDirectory
)

$ErrorActionPreference = "Stop"
$repoRoot = Split-Path -Parent $PSScriptRoot
$benchmarkProject = Join-Path $repoRoot "CopperScreen.Benchmarks\CopperScreen.Benchmarks.csproj"
$benchmarkAssembly = Join-Path $repoRoot "CopperScreen.Benchmarks\bin\$Configuration\net10.0\CopperScreen.Benchmarks.dll"
$artifactDirectory = Join-Path $repoRoot "artifacts\g6-requester-trace-gate"

# Frozen-family replays must not rebuild or replace the selected dependencies.
# Use a fresh evidence directory so a rerun cannot erase earlier gate evidence.
if ($BenchmarkAssemblyPath) {
    if (-not $SkipBuild) { throw "A frozen BenchmarkAssemblyPath requires -SkipBuild." }
    if (-not (Test-Path -LiteralPath $BenchmarkAssemblyPath -PathType Leaf)) {
        throw "Frozen benchmark assembly not found: $BenchmarkAssemblyPath"
    }
    $benchmarkAssembly = (Resolve-Path -LiteralPath $BenchmarkAssemblyPath).Path
}
if ($EvidenceDirectory) {
    $artifactDirectory = [System.IO.Path]::GetFullPath($EvidenceDirectory)
    if (Test-Path -LiteralPath $artifactDirectory) {
        if (-not (Test-Path -LiteralPath $artifactDirectory -PathType Container) -or
            @(Get-ChildItem -LiteralPath $artifactDirectory -Force).Count -ne 0) {
            throw "Custom EvidenceDirectory must be new or empty: $artifactDirectory"
        }
    }
}

function Remove-AuditFamily([string]$path) {
    Get-ChildItem -LiteralPath (Split-Path -Parent $path) -File |
        Where-Object { $_.Name.StartsWith((Split-Path -Leaf $path), [StringComparison]::Ordinal) } |
        ForEach-Object { Remove-Item -LiteralPath $_.FullName }
}

function Invoke-TraceAudit([int]$warmupFrames, [string]$mode) {
    $path = Join-Path $artifactDirectory "warmup-$warmupFrames-$mode.tsv"
    Remove-AuditFamily $path
    $arguments = @(
        $benchmarkAssembly, "--only", $Workload, "--profile", $Profile,
        "--cpu", "accurateM68000", "--warmup", $warmupFrames,
        "--frames", 1, "--repeat", 1, "--hardware-specialization",
        "--skip-presentation", "--no-phase-profile", "--kickstart-rom", $KickstartRom,
        "--slot-schedule-audit-limit", 1000000, "--slot-schedule-audit", $path)
    if ($mode -eq "stage5") { $arguments += @("--agnus-live-requester-stage", 5) }
    else { $arguments += "--agnus-slot-kernel" }

    $output = & dotnet @arguments 2>&1
    if ($LASTEXITCODE -ne 0) {
        $output | Out-Host
        throw "G6 $mode trace at warmup $warmupFrames failed with exit code $LASTEXITCODE."
    }
    $configuration = @($output | ForEach-Object { $_.ToString() } |
        Where-Object { $_.StartsWith("Warmup=") }) | Select-Object -Last 1
    if ($mode -eq "stage5" -and $configuration -notmatch "AgnusLiveRequesterStage=5") {
        throw "G6 trace reference did not activate Stage 5 at warmup $warmupFrames."
    }
    if ($mode -eq "kernel" -and $configuration -notmatch "Agnus=SlotKernel") {
        throw "G6 trace candidate did not activate the slot kernel at warmup $warmupFrames."
    }
    return $path
}

function Read-AuditRows([string]$path) {
    return @(Get-Content -LiteralPath $path | Where-Object { $_ -notlike "#*" } |
        ConvertFrom-Csv -Delimiter "`t")
}

function Get-Sha256([string]$path) {
    $stream = [System.IO.File]::OpenRead($path)
    try {
        $sha256 = [System.Security.Cryptography.SHA256]::Create()
        try { return ([BitConverter]::ToString($sha256.ComputeHash($stream))).Replace("-", "") }
        finally { $sha256.Dispose() }
    }
    finally { $stream.Dispose() }
}

function Assert-EqualFile([string]$stage5Path, [string]$kernelPath, [string]$label) {
    if ((Get-Sha256 $stage5Path) -ne (Get-Sha256 $kernelPath)) {
        throw "G6 requester trace STOP: pre-divergence $label sidecars differ."
    }
}

function ConvertTo-CanonicalAuditRows($rows) {
    $fields = @(
        "absolute_frame", "measured_frame", "beam_frame", "line", "hpos",
        "slot_cycle", "requested_cycle", "granted_cycle", "completed_cycle", "wait_cycles",
        "owner", "rw", "requester", "kind", "target", "address", "source",
        "source_a", "source_b", "source_c", "replaced", "replaced_owner", "fixed_owner",
        "cpu_accessible")
    return @($rows |
        Sort-Object @{ Expression = { [long]$_.slot_cycle } }, owner, address, requester, kind, rw |
        ForEach-Object {
            $row = $_
            ($fields | ForEach-Object { $row.$_ }) -join "`t"
        })
}

function Get-CanonicalAuditDifference($stage5Rows, $kernelRows) {
    $stage5Canonical = @(ConvertTo-CanonicalAuditRows $stage5Rows)
    $kernelCanonical = @(ConvertTo-CanonicalAuditRows $kernelRows)
    if ($stage5Canonical.Count -ne $kernelCanonical.Count) {
        return "row counts differ ($($stage5Canonical.Count) vs $($kernelCanonical.Count))."
    }
    for ($index = 0; $index -lt $stage5Canonical.Count; $index++) {
        if ($stage5Canonical[$index] -ne $kernelCanonical[$index]) {
            return "canonical row $index differs."
        }
    }
}

function Assert-CanonicalAuditEqual($stage5Rows, $kernelRows, [string]$label) {
    $difference = Get-CanonicalAuditDifference $stage5Rows $kernelRows
    if ($null -ne $difference) {
        throw "G6 requester trace STOP: $label $difference"
    }
}

function Assert-ExactAuditFamily([string]$stage5Path, [string]$kernelPath, [string]$label) {
    Assert-CanonicalAuditEqual (Read-AuditRows $stage5Path) (Read-AuditRows $kernelPath) $label
    foreach ($suffix in @("instructions.tsv", "custom-reads.tsv", "interrupts.tsv", "cia-interrupts.tsv", "cia-registers.tsv")) {
        Assert-EqualFile "$stage5Path.$suffix" "$kernelPath.$suffix" "$label $suffix"
    }
}

function Assert-Field($row, [string]$field, [string]$expected, [string]$label) {
    if ($null -eq $row -or $row.$field -ne $expected) {
        $actual = if ($null -eq $row) { "<missing>" } else { $row.$field }
        throw "G6 requester trace STOP: $label $field expected '$expected', actual '$actual'."
    }
}

if (-not (Test-Path -LiteralPath $KickstartRom -PathType Leaf)) { throw "Kickstart ROM not found: $KickstartRom" }
New-Item -ItemType Directory -Path $artifactDirectory -Force | Out-Null
if (-not $SkipBuild) {
    & dotnet build $benchmarkProject -c $Configuration --no-restore -p:UseAppHost=false
    if ($LASTEXITCODE -ne 0) { throw "G6 requester trace build failed with exit code $LASTEXITCODE." }
}

$preStage5 = Invoke-TraceAudit 362 "stage5"
$preKernel = Invoke-TraceAudit 362 "kernel"
Assert-ExactAuditFamily $preStage5 $preKernel "warmup-362"

$refreshStage5Path = Invoke-TraceAudit 363 "stage5"
$refreshKernelPath = Invoke-TraceAudit 363 "kernel"
Assert-ExactAuditFamily $refreshStage5Path $refreshKernelPath "warmup-363"

$spriteStage5Path = Invoke-TraceAudit 365 "stage5"
$spriteKernelPath = Invoke-TraceAudit 365 "kernel"
$spriteStage5 = Read-AuditRows $spriteStage5Path
$spriteKernel = Read-AuditRows $spriteKernelPath
# Exact parity is always permitted by G6. The historical exception is an
# allowance for that specific disagreement, not a requirement to reproduce it.
# Accept this stronger path only when every row and all five sidecars agree.
if ($null -eq (Get-CanonicalAuditDifference $spriteStage5 $spriteKernel)) {
    Assert-ExactAuditFamily $spriteStage5Path $spriteKernelPath "warmup-365"
    Write-Host "G6 requester-scoped trace checkpoint PASS"
    Write-Host "trace_oracle=exact"
    Write-Host "warmup_362_363_365=canonical-exact"
    Write-Host "sidecars=15/15 exact"
    exit 0
}
foreach ($cycle in @("51929038", "51929042")) {
    $stage5Row = @($spriteStage5 | Where-Object { $_.slot_cycle -eq $cycle }) | Select-Object -First 1
    $kernelRow = @($spriteKernel | Where-Object { $_.slot_cycle -eq $cycle }) | Select-Object -First 1
    Assert-Field $stage5Row "owner" "Cpu" "Stage 5 sprite-conflict row $cycle"
    Assert-Field $stage5Row "kind" "CpuInstructionFetch" "Stage 5 sprite-conflict row $cycle"
    Assert-Field $stage5Row "target" "ChipRam" "Stage 5 sprite-conflict row $cycle"
    Assert-Field $stage5Row "fixed_owner" "Sprite" "Stage 5 sprite-conflict row $cycle"
    Assert-Field $stage5Row "cpu_accessible" "0" "Stage 5 sprite-conflict row $cycle"
    Assert-Field $kernelRow "owner" "Sprite" "kernel sprite-conflict row $cycle"
    Assert-Field $kernelRow "kind" "Sprite" "kernel sprite-conflict row $cycle"
    Assert-Field $kernelRow "fixed_owner" "Sprite" "kernel sprite-conflict row $cycle"
    Assert-Field $kernelRow "cpu_accessible" "0" "kernel sprite-conflict row $cycle"
}

Write-Host "G6 requester-scoped trace checkpoint PASS"
Write-Host "pre_divergence_sidecars=5/5 exact"
Write-Host "warmup_363_physical_stream=canonical-exact"
Write-Host "approved_fixed_sprite_conflicts=51929038,51929042"

param(
    [Parameter(Mandatory = $true)]
    [string]$Cases,
    [Parameter(Mandatory = $true)]
    [string]$ProgressPath,
    [Parameter(Mandatory = $true)]
    [string]$ResultsPath,
    [switch]$DumpRaw
)

$repo = Split-Path -Parent $PSScriptRoot
$env:COPPER_AMIGA_VAMIGATS_ROOT = Join-Path $repo 'third_party\vAmigaTS'
$env:COPPER_AMIGA_VAMIGATS_CASES = $Cases
$env:COPPER_AMIGA_VAMIGATS_MAX_FRAMES = '543'
$env:COPPER_AMIGA_VAMIGATS_KICK13_ROM = 'C:\D-drive\TestData\ROM\Kickstart_13.rom'
$env:COPPER_AMIGA_VAMIGATS_COMPARE_RAW = '1'
$env:COPPER_AMIGA_VAMIGATS_DUMP_RAW = if ($DumpRaw) { '1' } else { '0' }
$env:COPPER_AMIGA_VAMIGATS_HARDWARE_SPECIALIZATION = '1'
$env:COPPER_AMIGA_VAMIGATS_STOP_ON_FIRST_FAILURE = '0'
$env:COPPER_AMIGA_VAMIGATS_TRACE_WRITES = '0'
$env:COPPER_AMIGA_VAMIGATS_TRACE_PRESENTATION = '0'
$env:COPPER_AMIGA_TRACE_BUS_ACCESSES = '0'
$env:COPPER_AMIGA_VAMIGATS_SKIP_RAW_OFFSET_SCAN = '1'
$env:COPPER_AMIGA_VAMIGATS_AGNUS_LIVE_STAGE = '0'
$env:COPPER_AMIGA_VAMIGATS_CASE_TIMEOUT_SECONDS = '180'
$env:COPPER_AMIGA_VAMIGATS_PROGRESS_PATH = $ProgressPath
$env:COPPER_AMIGA_VAMIGATS_RESULTS_PATH = $ResultsPath

dotnet test (Join-Path $repo 'CopperScreen.Tests\CopperScreen.Tests.csproj') `
    -c Release `
    --no-build `
    --no-restore `
    --filter 'FullyQualifiedName~VAmigaTsAdfCorpusTests' `
    --logger 'console;verbosity=minimal'
exit $LASTEXITCODE

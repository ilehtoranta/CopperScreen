using System.IO.Compression;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.Json;
using CopperMod.Amiga;
using CopperMod.Amiga.Firmware;

// Host-only native replay/measurement. Hardware implementations are unchanged.
// Host telemetry and gate decisions belong to the paired external wrapper.
internal static class NativeGameplayReplay
{
    private sealed record Entry(int Frame, byte MouseButtons = 0, short MouseDeltaX = 0,
        short MouseDeltaY = 0, ushort KeyCode = 0, byte JoystickPort0 = 0,
        byte JoystickPort1 = 0, string? AdfPath = null, bool EjectAdf = false);

    internal static bool TryRun(string[] args)
    {
        var measure = args.Contains("--native-gameplay-measure");
        if (!measure && !args.Contains("--native-gameplay-replay")) return false;
        if (measure && args.Contains("--native-gameplay-replay"))
            throw new ArgumentException("Choose replay or measurement, not both.");
        var values = new Dictionary<string, string>();
        for (var i = 0; i < args.Length; i++)
        {
            if (args[i] is "--native-gameplay-replay" or "--native-gameplay-measure") continue;
            if (args[i] is not ("--rom" or "--adf" or "--input-script" or "--frames" or "--warmup" or "--output") || i + 1 >= args.Length)
                throw new ArgumentException($"Unknown or incomplete replay option: {args[i]}");
            values.Add(args[i], args[++i]);
        }
        var frames = int.Parse(values["--frames"]);
        if (frames <= 0) throw new ArgumentException("Positive frame count required.");
        var warmup = values.TryGetValue("--warmup", out var warmupText) ? int.Parse(warmupText) : 0;
        if ((measure && (warmup != 10920 || frames != 3600)) || (!measure && warmup != 0))
            throw new ArgumentException("H6d measurement requires 10920 boot+warmup fields and 3600 measured fields; replay requires zero warmup.");
        var totalFrames = checked(warmup + frames);
        var output = Path.GetFullPath(values["--output"]);
        if (Directory.Exists(output)) throw new ArgumentException("Use a new evidence directory.");
        var scriptPath = Path.GetFullPath(values["--input-script"]);
        var entries = JsonSerializer.Deserialize<Entry[]>(File.ReadAllText(scriptPath),
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? throw new ArgumentException("Empty script.");
        var media = new AmigaDiskImage?[entries.Length];
        for (var i = 0; i < entries.Length; i++)
        {
            var e = entries[i];
            if (e is null || e.Frame < 0 || (i > 0 && e.Frame < entries[i - 1].Frame) ||
                e.KeyCode != 0 || e.JoystickPort0 != 0 || e.JoystickPort1 != 0 || e.MouseButtons > 3 ||
                (e.EjectAdf && e.AdfPath is not null) || (e.AdfPath is not null && string.IsNullOrWhiteSpace(e.AdfPath)))
                throw new ArgumentException("Replay requires ordered mouse/media-only entries; no silent input omission.");
            if (measure && e.Frame >= warmup && e.Frame < totalFrames && (e.EjectAdf || e.AdfPath is not null))
                throw new ArgumentException("Media changes must precede measurement.");
            if (e.AdfPath is not null)
                media[i] = AmigaDiskImage.FromAdfBytes(ReadImage(Path.GetFullPath(e.AdfPath, Path.GetDirectoryName(scriptPath)!), ".adf"));
        }
        var options = MachineOptions.ForProfile(MachineProfile.A500Pal512KBoot)
            .WithFloppyDriveCount(1).WithRealTimeClock(false).WithBusAccessLogging(false)
            .WithAgnusBusArbitration(AgnusBusArbitrationMode.Legacy)
            .WithKickstart(KickstartConfiguration.FromRomImage(KickstartVersion.Kickstart13, ReadImage(values["--rom"], ".rom")));
        using var machine = new Machine(options);
        var boot = new AmigaBootController(machine);
        var disk = AmigaDiskImage.FromAdfBytes(ReadImage(values["--adf"], ".adf"));
        boot.StartKickstartRomBoot(disk);
        machine.Bus.Disk.Drive0.Insert(disk, writeProtected: true);
        var width = machine.Bus.Display.Width;
        var height = machine.Bus.RasterTiming.PresentationLowResHeight;
        var pixels = new uint[width * height];
        var audio = new AudioSchedule(machine);
        Directory.CreateDirectory(output);
        using var log = new StreamWriter(Path.Combine(output, "replay.tsv")) { AutoFlush = true };
        log.WriteLine("frame\tcycle\tpc\tpixelsSha256\taudioNonzero\taudioFrames\tdmacon\tbplcon0\tcylinder");
        Console.WriteLine($"{(measure ? "MEASUREMENT" : "DIAGNOSTIC ONLY")}: Legacy A500 PAL OCS 68000 512K+512K DF0-readonly KS1.3; {width}x{height} native Legacy pixels; 48000 Hz stereo; no automatic gate verdict.");
        Console.WriteLine($"scriptSha256={Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(scriptPath)))}");
        var next = 0;
        long start = 0;
        var stopwatch = new Stopwatch();
        long allocatedBefore = 0, allocatedBytes = 0, measuredAudioFrames = 0;
        var activeAudioFields = 0;
        ulong outputChecksum = 1469598103934665603UL;
        string? startPixelHash = null;
        for (var frame = 0; frame < totalFrames; frame++)
        {
            if (measure && frame == warmup)
            {
                startPixelHash = Convert.ToHexString(SHA256.HashData(System.Runtime.InteropServices.MemoryMarshal.AsBytes(pixels.AsSpan())));
                WriteBmp(Path.Combine(output, "start.bmp"), pixels, width, height);
                GC.Collect(); GC.WaitForPendingFinalizers(); GC.Collect();
                allocatedBefore = GC.GetAllocatedBytesForCurrentThread();
                stopwatch.Start();
            }
            while (next < entries.Length && entries[next].Frame == frame)
            {
                var e = entries[next];
                if (e.EjectAdf) machine.Bus.Disk.Drive0.Eject();
                if (media[next] is { } inserted) machine.Bus.Disk.Drive0.Insert(inserted, markChanged: true, writeProtected: true);
                machine.Bus.GamePort0FirePressed = (e.MouseButtons & 1) != 0;
                machine.Bus.GamePort0SecondFirePressed = (e.MouseButtons & 2) != 0;
                machine.Bus.MoveGamePortMouse(0, e.MouseDeltaX, e.MouseDeltaY);
                if (!measure) Console.WriteLine($"INPUT beforeFrame={frame} cycle={machine.Cpu.State.Cycles} entry={next}");
                next++;
            }
            var end = machine.Bus.GetFrameStopCycle(start);
            machine.Bus.Display.BeginPresentationFrame(new PresentationFrameTarget(pixels), start, end);
            audio.BeginExecution(start, end);
            try
            {
                var result = boot.ContinueExecutionUntilCycle(end, 250_000, audio);
                if (machine.Cpu.State.Cycles < end || machine.Cpu.State.Halted)
                    throw new InvalidOperationException($"Incomplete frame={frame + 1} pc={machine.Cpu.State.ProgramCounter:X8}: {string.Join(";", result.Diagnostics.Select(d => d.Code + ":" + d.Message))}");
                audio.CompleteExecution(end);
                machine.Bus.AdvanceHardwareTo(end);
                machine.Bus.Display.CompletePresentationFrame(end);
            }
            catch { machine.Bus.Display.AbortPresentationFrame(); throw; }
            if (machine.Bus.GetFrameStopCycle(start) != end || machine.Bus.Display.InterlaceEnabled)
                throw new InvalidOperationException("Changed field geometry requires explicit replay support, not a successful result.");
            start = end;
            var completed = frame + 1;
            if (measure && frame >= warmup)
            {
                outputChecksum = ConsumeOutputs(pixels, audio.Samples, outputChecksum, frame - warmup);
                measuredAudioFrames += audio.Count;
                if (audio.Nonzero) activeAudioFields++;
                if (completed == totalFrames)
                {
                    stopwatch.Stop();
                    allocatedBytes = GC.GetAllocatedBytesForCurrentThread() - allocatedBefore;
                }
            }
            if ((!measure && (completed % 600 == 0 || completed is 10320 or 10920 or 14520)) || completed == totalFrames)
            {
                var bytes = System.Runtime.InteropServices.MemoryMarshal.AsBytes(pixels.AsSpan());
                var hash = Convert.ToHexString(SHA256.HashData(bytes));
                WriteBmp(Path.Combine(output, $"frame-{completed:D5}.bmp"), pixels, width, height);
                File.WriteAllBytes(Path.Combine(output, $"chip-{completed:D5}.bin"), machine.Bus.ChipRam.ToArray());
                log.WriteLine($"{completed}\t{end}\t{machine.Cpu.State.ProgramCounter:X8}\t{hash}\t{audio.Nonzero}\t{audio.Count}\t{machine.Bus.Paula.Dmacon:X4}\t{machine.Bus.Display.CaptureSnapshot().Bplcon0:X4}\t{machine.Bus.Disk.Drive0.Cylinder}");
                Console.WriteLine($"CHECKPOINT frame={completed} cycle={end} pc={machine.Cpu.State.ProgramCounter:X8} audioNonzero={audio.Nonzero} pixels={hash}");
            }
        }
        if (measure)
        {
            var cpu = machine.Cpu.State;
            var cpuHash = 1469598103934665603UL;
            foreach (var value in new ulong[] { cpu.ProgramCounter, cpu.StatusRegister, (ulong)cpu.Cycles }) cpuHash = (cpuHash ^ value) * 1099511628211UL;
            foreach (var value in cpu.D) cpuHash = (cpuHash ^ value) * 1099511628211UL;
            foreach (var value in cpu.A) cpuHash = (cpuHash ^ value) * 1099511628211UL;
            var endPixelHash = Convert.ToHexString(SHA256.HashData(System.Runtime.InteropServices.MemoryMarshal.AsBytes(pixels.AsSpan())));
            var chipHash = Convert.ToHexString(SHA256.HashData(machine.Bus.ChipRam));
            Console.WriteLine(FormattableString.Invariant($"engine=legacy-native warmup={warmup} frames={frames} completed={totalFrames} fps={frames / stopwatch.Elapsed.TotalSeconds:F2} cycle={start} cpuCycle={cpu.Cycles} cpu=0x{cpuHash:X16} output=0x{outputChecksum:X16} startPixels={startPixelHash} endPixels={endPixelHash} chip={chipHash} pixels={pixels.Length} audioSamples={audio.Count * 2} measuredAudioFrames={measuredAudioFrames} activeAudioFields={activeAudioFields} pcm=real allocated={allocatedBytes} adf=True unsupported=not-instrumented"));
        }
        else Console.WriteLine("REPLAY COMPLETE: inspect gameplay/input/sound evidence; not an acceptance or throughput verdict.");
        return true;
    }

    // Same bounded consumption counts as the Lightweight runner. Native pixel
    // dimensions and PCM representation intentionally differ between engines.
    private static ulong ConsumeOutputs(ReadOnlySpan<uint> pixels, ReadOnlySpan<float> audio, ulong hash, int frame)
    {
        if (audio.Length == 0) throw new InvalidOperationException("A measured field omitted audio output.");
        const ulong prime = 1099511628211UL;
        hash = (hash ^ (uint)pixels.Length) * prime;
        hash = (hash ^ (uint)audio.Length) * prime;
        var pixelIndex = frame * 131 % pixels.Length;
        for (var i = 0; i < 257; i++)
        {
            hash = (hash ^ pixels[pixelIndex]) * prime;
            pixelIndex += 557;
            if (pixelIndex >= pixels.Length) pixelIndex -= pixels.Length;
        }
        var audioIndex = frame * 17 % audio.Length;
        for (var i = 0; i < 61; i++)
        {
            hash = (hash ^ BitConverter.SingleToUInt32Bits(audio[audioIndex])) * prime;
            audioIndex += 31;
            if (audioIndex >= audio.Length) audioIndex -= audio.Length;
        }
        return hash;
    }

    private static byte[] ReadImage(string path, string extension)
    {
        if (!path.EndsWith(".zip", StringComparison.OrdinalIgnoreCase)) return File.ReadAllBytes(path);
        using var zip = ZipFile.OpenRead(path);
        var entry = zip.Entries.Single(e => e.FullName.EndsWith(extension, StringComparison.OrdinalIgnoreCase));
        using var stream = entry.Open();
        using var memory = new MemoryStream();
        stream.CopyTo(memory);
        return memory.ToArray();
    }

    private static void WriteBmp(string path, uint[] pixels, int width, int height)
    {
        using var writer = new BinaryWriter(File.Create(path));
        writer.Write((ushort)0x4D42); writer.Write(54 + pixels.Length * 4); writer.Write(0); writer.Write(54);
        writer.Write(40); writer.Write(width); writer.Write(-height); writer.Write((ushort)1); writer.Write((ushort)32);
        writer.Write(0); writer.Write(pixels.Length * 4); writer.Write(0); writer.Write(0); writer.Write(0); writer.Write(0);
        foreach (var pixel in pixels) writer.Write(pixel);
    }

    private sealed class AudioSchedule(Machine machine) : IAmigaExecutionBoundarySchedule
    {
        private readonly float[] _samples = new float[2048];
        private long _ordinal = 1;
        private long _end;
        private long Next => (_ordinal * machine.Bus.RasterTiming.CpuClockHz + 47999) / 48000;
        internal int Count { get; private set; }
        internal bool Nonzero { get; private set; }
        internal ReadOnlySpan<float> Samples => _samples.AsSpan(0, Count * 2);
        public void BeginFrame() { }
        public void CompleteFrame() { }
        public void BeginExecution(long startCycle, long endCycle) { _end = endCycle; Count = 0; Nonzero = false; }
        public long GetNextBoundaryCycle(long currentCycle, long targetCycle) => Math.Clamp(Next, currentCycle + 1, targetCycle);
        public void AdvanceThrough(long previousCycle, long currentCycle)
        {
            while (Next <= Math.Min(currentCycle, _end))
            {
                if (Count >= _samples.Length / 2) throw new InvalidOperationException("Audio field buffer overflow.");
                machine.Bus.Paula.RenderSample(Next, _samples, Count, 2, advanceRegisterObservable: false);
                Nonzero |= _samples[Count * 2] != 0 || _samples[Count * 2 + 1] != 0;
                Count++; _ordinal++;
            }
        }
        public void CompleteExecution(long endCycle) => AdvanceThrough(0, endCycle);
    }
}

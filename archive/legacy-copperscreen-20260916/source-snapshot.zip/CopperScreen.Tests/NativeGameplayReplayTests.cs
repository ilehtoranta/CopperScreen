namespace CopperScreen.Tests;

public sealed class NativeGameplayReplayTests
{
    [Fact]
    public void UnselectedModeDoesNotInterceptExistingBenchmarks()
        => Assert.False(NativeGameplayReplay.TryRun(["--smoke"]));

    [Fact]
    public void UnknownOptionsCannotSilentlyChangeTheWorkload()
        => Assert.Throws<ArgumentException>(() => NativeGameplayReplay.TryRun(["--native-gameplay-replay", "--skip-audio"]));

    [Fact]
    public void EmptyFrameRunCannotReportCompletion()
        => Assert.Throws<ArgumentException>(() => NativeGameplayReplay.TryRun(["--native-gameplay-replay", "--frames", "0"]));

    [Fact]
    public void MeasurementCannotUseAReplayOrShortenedProtocol()
    {
        Assert.Throws<ArgumentException>(() => NativeGameplayReplay.TryRun(["--native-gameplay-measure", "--native-gameplay-replay"]));
        Assert.Throws<ArgumentException>(() => NativeGameplayReplay.TryRun(["--native-gameplay-measure", "--frames", "360", "--warmup", "600"]));
    }

    [Theory]
    [InlineData("[{\"frame\":10920,\"ejectAdf\":true}]")]
    [InlineData("[{\"frame\":14519,\"adfPath\":\"unavailable.adf\"}]")]
    public void MeasurementRejectsTimedMediaChangesBeforeReadingMedia(string json)
    {
        var directory = Path.Combine(Path.GetTempPath(), "native-measure-test-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory);
        var script = Path.Combine(directory, "script.json");
        File.WriteAllText(script, json);
        try
        {
            Assert.Throws<ArgumentException>(() => NativeGameplayReplay.TryRun([
                "--native-gameplay-measure", "--frames", "3600", "--warmup", "10920",
                "--output", Path.Combine(directory, "output"), "--input-script", script,
                "--rom", "unavailable.rom", "--adf", "unavailable.adf"]));
        }
        finally { File.Delete(script); Directory.Delete(directory); }
    }

    [Theory]
    [InlineData("[{\"frame\":-1}]")]
    [InlineData("[{\"frame\":2},{\"frame\":1}]")]
    [InlineData("[{\"frame\":0,\"keyCode\":32}]")]
    [InlineData("[{\"frame\":0,\"joystickPort0\":1}]")]
    [InlineData("[{\"frame\":0,\"mouseButtons\":4}]")]
    [InlineData("[{\"frame\":0,\"ejectAdf\":true,\"adfPath\":\"disk.adf\"}]")]
    public void UnsupportedOrInvalidScriptFailsBeforeMachineAndMediaLoading(string json)
    {
        var directory = Path.Combine(Path.GetTempPath(), "native-replay-test-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory);
        var script = Path.Combine(directory, "script.json");
        File.WriteAllText(script, json);
        try
        {
            Assert.Throws<ArgumentException>(() => NativeGameplayReplay.TryRun([
                "--native-gameplay-replay", "--frames", "1", "--output", Path.Combine(directory, "output"),
                "--input-script", script, "--rom", "unavailable.rom", "--adf", "unavailable.adf"]));
            Assert.False(Directory.Exists(Path.Combine(directory, "output")));
        }
        finally { File.Delete(script); Directory.Delete(directory); }
    }
}

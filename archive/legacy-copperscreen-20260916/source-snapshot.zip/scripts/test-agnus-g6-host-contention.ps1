$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'agnus-g6-host-load.ps1')
$script:passed = 0
function Check([string]$Name, [scriptblock]$Body) {
    & $Body
    $script:passed++
    Write-Host "PASS: $Name"
}
function Reject([scriptblock]$Body) {
    $rejected = $false
    try { & $Body } catch { $rejected = $true }
    if (-not $rejected) { throw 'Expected rejection.' }
}
function Load([double]$Selected=0,[double]$Sibling=0,[double]$Package=0,[double]$Seconds=2) {
    [pscustomobject]@{ Selected=$Selected; Sibling=$Sibling; Package=$Package; Seconds=$Seconds; Workloads=@() }
}
Check 'ordinary background work elsewhere is allowed' {
    $state=@{}; 1..20 | ForEach-Object { Update-G6HostLoadState $state (Load 3 4 8) }
}
Check 'two-second foreground burst is allowed' {
    $state=@{}; Update-G6HostLoadState $state (Load 90 90 40); Update-G6HostLoadState $state (Load)
}
foreach ($dimension in @('Selected','Sibling','Package')) {
    Check "$dimension rejects ten continuous seconds, not eight" {
        $state=@{}; $load=Load; $load.$dimension=25
        1..4 | ForEach-Object { Update-G6HostLoadState $state $load }
        Reject { Update-G6HostLoadState $state $load }
    }
}
Check 'nonconsecutive bursts do not accumulate' {
    $state=@{}; 1..10 | ForEach-Object {
        Update-G6HostLoadState $state (Load 80 80 80 4)
        Update-G6HostLoadState $state (Load)
    }
}
Check 'actual elapsed time, not tick count' {
    $state=@{}; Update-G6HostLoadState $state (Load 25 0 0 6)
    Reject { Update-G6HostLoadState $state (Load 25 0 0 4) }
}
Check 'competing test workload rejected even with low CPU' {
    $load=Load; $load.Workloads=@('testhost.exe[123]')
    Reject { Update-G6HostLoadState @{} $load }
}
function Snapshot([double]$Idle, [double]$Time, [double]$BenchmarkSeconds) {
    $cores=@{}; 0..3 | ForEach-Object { $cores[$_] = [pscustomobject]@{Idle=[decimal]$Idle; Time=[decimal]$Time} }
    [pscustomobject]@{Cores=$cores; BenchmarkSeconds=$BenchmarkSeconds; Workloads=@();TimeSeconds=$Time/10000000.0}
}
Check 'raw counters subtract benchmark only from its selected CPU and package' {
    $a=Snapshot 0 100000000 10; $b=Snapshot 20000000 120000000 12
    $b.Cores[2].Idle=0; $b.Cores[3].Idle=10000000
    $load=Get-G6HostLoad $a $b 2 @(2,3)
    if($load.Selected -ne 0 -or $load.Sibling -ne 50 -or $load.Package -ne 12.5 -or $load.Seconds -ne 2){throw 'Incorrect load calculation'}
}
Check 'missing core telemetry rejected' {
    $a=Snapshot 0 100000000 0; $b=Snapshot 10000000 120000000 0
    $b.Cores.Remove(3); Reject { Get-G6HostLoad $a $b 2 @(2,3) }
}
Check 'independent native CPU accounting ticks use monotonic wall duration' {
    $a=Snapshot 0 100000000 0; $b=Snapshot 20000000 120000000 0
    $b.Cores[0].Time=125000000; $b.Cores[0].Idle=25000000
    $load=Get-G6HostLoad $a $b 2 @(2,3)
    if($load.Seconds -ne 2 -or $load.Package -ne 0){throw 'Incorrect per-core denominator or wall duration'}
}
Check 'stale telemetry rejected' {
    $a=Snapshot 0 100000000 0; Reject { Get-G6HostLoad $a $a 2 @(2,3) }
}
Check 'long telemetry gap rejected' {
    Reject { Get-G6HostLoad (Snapshot 0 100000000 0) (Snapshot 0 210000000 0) 2 @(2,3) }
}
Check 'small inconsistent native idle delta rejected' {
    Reject { Get-G6HostLoad (Snapshot 0 100000000 0) (Snapshot 20100000 120000000 0) 2 @(2,3) }
}
Check 'large idle-counter inconsistency rejected' {
    Reject { Get-G6HostLoad (Snapshot 0 100000000 0) (Snapshot 21000000 120000000 0) 2 @(2,3) }
}
Check 'snapshot excludes own benchmark and normal apps, but sees real test/build commands' {
    function Get-G6ProcessorCounters { [pscustomobject]@{Index=0;Idle=0;Time=100000000} }
    function Get-CimInstance {
        [CmdletBinding()]param([string]$ClassName)
        if($ClassName -eq 'Win32_PerfRawData_PerfOS_Processor') {
            [pscustomobject]@{Name='0';PercentProcessorTime=0;Timestamp_Sys100NS=100000000}
            return
        }
        @(
            [pscustomobject]@{Name='ChatGPT.exe';ProcessId=101;CommandLine='ChatGPT.exe'},
            [pscustomobject]@{Name='dotnet.exe';ProcessId=102;CommandLine='dotnet test tests.csproj'},
            [pscustomobject]@{Name='dotnet.exe';ProcessId=103;CommandLine='dotnet build app.csproj'},
            [pscustomobject]@{Name='dotnet.exe';ProcessId=104;CommandLine='dotnet MSBuild.dll /nodemode:1 /nodeReuse:true'},
            [pscustomobject]@{Name='dotnet.exe';ProcessId=105;CommandLine='dotnet CopperScreen.Benchmarks.dll'}
        )
    }
    $own=[pscustomobject]@{Id=105;TotalProcessorTime=[timespan]::FromSeconds(2)}
    $snapshot=Get-G6HostSnapshot $own
    if(($snapshot.Workloads -join ',') -ne 'dotnet.exe[102],dotnet.exe[103]'){throw 'Incorrect workload classification'}
}
foreach($file in @('run-agnus-g6-controlled-performance.ps1','agnus-g6-host-load.ps1')) {
    $tokens=$null; $errors=$null
    [void][Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot $file),[ref]$tokens,[ref]$errors)
    if($errors.Count){throw "Syntax errors: $file"}
}
Write-Host "G6 host-policy v2 tests PASS: $script:passed cases; no benchmark, process-affinity change or performance acceptance."

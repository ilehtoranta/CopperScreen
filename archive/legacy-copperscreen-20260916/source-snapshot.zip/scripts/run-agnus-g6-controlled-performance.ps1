param(
    [string]$Configuration = "Release",
    [int]$WarmupFrames = 600,
    [int]$MeasuredFrames = 360,
    [int]$SamplesPerMode = 3,
    [int]$LogicalProcessor = 2,
    [int]$ExpectedEfficiencyClass = 1,
    [double]$MinimumCandidateFps = 45.0,
    [double]$MaximumSpreadPercent = 10.0,
    [int]$PreflightSeconds = 10,
    [int]$CooldownSeconds = 10,
    [double]$CompetingCorePercent = 25.0,
    [double]$CompetingPackagePercent = 25.0,
    [int]$SustainedContentionSeconds = 10,
    [string]$ExpectedCandidateFramebuffer = "0/1/0x0B7A1325",
    [string]$ExpectedCandidateDskBytr = "0xA055",
    [string]$Workload = "Lemmings SR",
    [string]$Profile = "expanded-kickstart13.json",
    [string]$KickstartRom = "D:\TestData\ROM\Kickstart_13.rom",
    [switch]$SkipBuild,
    [string]$BenchmarkAssemblyPath,
    [hashtable]$ExpectedAssemblyHashes = @{},
    [switch]$Quick
)

$ErrorActionPreference = "Stop"
foreach ($diagnosticSwitch in @('COPPER_AGNUS_G6_DIAGNOSTICS', 'COPPER_DDF_WORKLOAD_DIAGNOSTICS', 'COPPER_BOUNDARY_WORKLOAD_DIAGNOSTICS')) {
    if ([Environment]::GetEnvironmentVariable($diagnosticSwitch) -eq '1') {
        throw "Disable diagnostic instrumentation before controlled throughput: $diagnosticSwitch"
    }
}
. (Join-Path $PSScriptRoot 'agnus-g6-host-load.ps1')
$repoRoot = Split-Path -Parent $PSScriptRoot
$benchmarkProject = Join-Path $repoRoot "CopperScreen.Benchmarks\CopperScreen.Benchmarks.csproj"
$benchmarkAssembly = Join-Path $repoRoot "CopperScreen.Benchmarks\bin\$Configuration\net10.0\CopperScreen.Benchmarks.dll"
if ($BenchmarkAssemblyPath) {
    if (-not $SkipBuild) { throw "A frozen BenchmarkAssemblyPath requires -SkipBuild." }
    if (-not (Test-Path -LiteralPath $BenchmarkAssemblyPath -PathType Leaf)) {
        throw "Frozen benchmark assembly not found: $BenchmarkAssemblyPath"
    }
    $benchmarkAssembly = (Resolve-Path -LiteralPath $BenchmarkAssemblyPath).Path
}
$affinityMask = [int64]1 -shl $LogicalProcessor

if ($Quick) {
    $WarmupFrames = 2
    $MeasuredFrames = 1
    $SamplesPerMode = 1
    $PreflightSeconds = [Math]::Min($PreflightSeconds, 2)
    $CooldownSeconds = 0
}
if ($SamplesPerMode -lt 1) { throw "SamplesPerMode must be positive." }
if ($LogicalProcessor -lt 0 -or $LogicalProcessor -ge 63) { throw "LogicalProcessor must be between 0 and 62." }
if ($CompetingCorePercent -le 0 -or $CompetingCorePercent -gt 100 -or
    $CompetingPackagePercent -le 0 -or $CompetingPackagePercent -gt 100 -or
    $SustainedContentionSeconds -le 0) { throw 'Invalid host-load policy limits.' }
if (-not $Quick -and $PreflightSeconds -lt $SustainedContentionSeconds) {
    throw 'Formal preflight must cover the sustained-contention window.'
}

Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

public static class CpuSetProbe
{
    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool GetSystemCpuSetInformation(
        IntPtr information, uint bufferLength, out uint returnedLength,
        IntPtr process, uint flags);

    public sealed class Entry
    {
        public byte LogicalProcessorIndex { get; set; }
        public byte CoreIndex { get; set; }
        public byte EfficiencyClass { get; set; }
        public ushort Group { get; set; }
    }

    public static Entry[] Read()
    {
        uint length;
        GetSystemCpuSetInformation(IntPtr.Zero, 0, out length, IntPtr.Zero, 0);
        if (length == 0) throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
        IntPtr buffer = Marshal.AllocHGlobal((int)length);
        try
        {
            if (!GetSystemCpuSetInformation(buffer, length, out length, IntPtr.Zero, 0))
                throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
            var result = new List<Entry>();
            int offset = 0;
            while (offset < length)
            {
                IntPtr item = IntPtr.Add(buffer, offset);
                int size = Marshal.ReadInt32(item, 0);
                int type = Marshal.ReadInt32(item, 4);
                if (size <= 0) break;
                if (type == 0)
                {
                    result.Add(new Entry {
                        Group = (ushort)Marshal.ReadInt16(item, 12),
                        LogicalProcessorIndex = Marshal.ReadByte(item, 14),
                        CoreIndex = Marshal.ReadByte(item, 15),
                        EfficiencyClass = Marshal.ReadByte(item, 18)
                    });
                }
                offset += size;
            }
            return result.ToArray();
        }
        finally { Marshal.FreeHGlobal(buffer); }
    }
}
'@

function Assert-CleanPreflight {
    Write-Host "Preflight: sampling core/sibling/package load for $PreflightSeconds second(s)."
    $before = Get-G6HostSnapshot
    $state = @{}
    $clock = [Diagnostics.Stopwatch]::StartNew()
    while ($clock.Elapsed.TotalSeconds -lt $PreflightSeconds) {
        Start-Sleep -Seconds 2
        $after = Get-G6HostSnapshot
        $load = Get-G6HostLoad $before $after $LogicalProcessor $protectedLogicalProcessors
        Write-G6HostLoad $load
        Update-G6HostLoadState $state $load $CompetingCorePercent $CompetingPackagePercent $SustainedContentionSeconds
        $before = $after
    }
}

function Convert-ToDouble {
    param([string]$Value)
    $number = 0.0
    if ([double]::TryParse($Value, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::CurrentCulture, [ref]$number)) { return $number }
    if ([double]::TryParse($Value, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$number)) { return $number }
    $normalized = $Value.Replace(',', '.')
    if ([double]::TryParse($normalized, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$number)) { return $number }
    throw "Cannot parse numeric benchmark value '$Value'."
}

function Invoke-ControlledSample {
    param([ValidateSet("slot-kernel", "legacy")][string]$Mode, [int]$Ordinal)

    $modeArgument = if ($Mode -eq "slot-kernel") { "--agnus-slot-kernel" } else { "--agnus-legacy" }
    $arguments = @(
        $benchmarkAssembly, "--only", $Workload, "--profile", $Profile,
        "--cpu", "accurateM68000", "--warmup", $WarmupFrames,
        "--frames", $MeasuredFrames, "--repeat", "1",
        "--hardware-specialization", "--skip-presentation", "--no-phase-profile",
        "--kickstart-rom", $KickstartRom, $modeArgument
    )
    $startInfo = [Diagnostics.ProcessStartInfo]::new("dotnet")
    $startInfo.UseShellExecute = $false
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $startInfo.Arguments = ($arguments | ForEach-Object {
        $text = [string]$_
        '"' + $text.Replace('"', '\"') + '"'
    }) -join ' '

    $process = [Diagnostics.Process]::Start($startInfo)
    try {
        $process.ProcessorAffinity = [intptr]$affinityMask
        $process.PriorityClass = [Diagnostics.ProcessPriorityClass]::Normal
        if ([int64]$process.ProcessorAffinity -ne $affinityMask -or $process.PriorityClass -ne "Normal") {
            throw "Benchmark affinity or priority confirmation failed."
        }
        $standardOutput = $process.StandardOutput.ReadToEndAsync()
        $standardError = $process.StandardError.ReadToEndAsync()
        $loadState = @{}
        $before = Get-G6HostSnapshot $process
        do {
            $finished = $process.WaitForExit(2000)
            $process.Refresh()
            if (-not $process.HasExited -and ([int64]$process.ProcessorAffinity -ne $affinityMask -or $process.PriorityClass -ne 'Normal')) {
                throw 'G6 performance INVALID / RERUN: affinity or priority changed.'
            }
            # Pass the retained Process object CPU time through snapshots even
            # if the child exits during telemetry collection.
            $after = Get-G6HostSnapshot $process
            $load = Get-G6HostLoad $before $after $LogicalProcessor $protectedLogicalProcessors
            Write-G6HostLoad $load
            Update-G6HostLoadState $loadState $load $CompetingCorePercent $CompetingPackagePercent $SustainedContentionSeconds
            $before = $after
        } while (-not $finished)
        $output = $standardOutput.Result
        $errorText = $standardError.Result
        if ($process.ExitCode -ne 0) { throw "Benchmark exited $($process.ExitCode): $errorText" }

        $lines = @($output -split "`r?`n")
        $configurationLine = $lines | Where-Object { $_.StartsWith("Warmup=") } | Select-Object -Last 1
        $headerLine = $lines | Where-Object { $_.StartsWith("name`tagnus`tbackend`t") } | Select-Object -Last 1
        $resultLine = $lines | Where-Object { $_.StartsWith("$Workload`t") } | Select-Object -Last 1
        if (-not $configurationLine -or -not $headerLine -or -not $resultLine) { throw "Unparseable $Mode benchmark output." }
        if ($Mode -eq "slot-kernel" -and $configurationLine -notmatch "Agnus=SlotKernel") { throw "Slot-kernel mode was not activated." }
        if ($Mode -eq "legacy" -and $configurationLine -notmatch "Agnus=(ForcedLegacy|Legacy)") { throw "Forced-legacy mode was not activated." }
        $headers = $headerLine -split "`t"
        $values = $resultLine -split "`t"
        if ($headers.Count -ne $values.Count) { throw "Benchmark column count mismatch." }
        $result = [ordered]@{}
        for ($index = 0; $index -lt $headers.Count; $index++) { $result[$headers[$index]] = $values[$index] }
        $sample = [pscustomobject]@{
            Mode = $Mode
            Ordinal = $Ordinal
            Fps = Convert-ToDouble $result["frames/sec"]
            Framebuffer = $result["framebuffer"]
            Audio = $result["audio"]
            Disk = ($result["disk"] -split ",sched=", 2)[0]
            AllocatedBytes = $result["allocated bytes"]
            Status = ($result["status"] -split " \| ", 2)[0]
        }
        if ($Mode -eq "slot-kernel") {
            if ($sample.Framebuffer -ne $ExpectedCandidateFramebuffer) {
                throw "G6 performance STOP: candidate framebuffer $($sample.Framebuffer) differs from accepted $ExpectedCandidateFramebuffer."
            }
            if ($sample.Disk -notmatch "bytr=$([regex]::Escape($ExpectedCandidateDskBytr))(?:,|$)") {
                throw "G6 performance STOP: candidate disk fingerprint does not contain accepted DSKBYTR=$ExpectedCandidateDskBytr."
            }
        }
        return $sample
    }
    finally {
        if (-not $process.HasExited) { $process.Kill($true) }
        $process.Dispose()
    }
}

if (-not (Test-Path -LiteralPath $KickstartRom -PathType Leaf)) { throw "Kickstart ROM not found: $KickstartRom" }
if (-not $SkipBuild) {
    & dotnet build $benchmarkProject -c $Configuration --no-restore -p:UseAppHost=false
    if ($LASTEXITCODE -ne 0) { throw "Benchmark build failed with exit code $LASTEXITCODE." }
}
if (-not (Test-Path -LiteralPath $benchmarkAssembly -PathType Leaf)) { throw "Benchmark assembly not found: $benchmarkAssembly" }

# Bind throughput evidence to the same family as the preceding correctness gates.
# Hashes are supplied by the caller, never copied from historical gate defaults.
$assemblyDirectory = Split-Path -Parent $benchmarkAssembly
foreach ($name in @('CopperScreen.Benchmarks.dll', 'CopperScreen.dll', 'CopperMod.Amiga.dll', 'Copper68k.dll', 'CopperMod.Amiga.Emulator.dll')) {
    $assemblyPath = Join-Path $assemblyDirectory $name
    $actualHash = (Get-FileHash -LiteralPath $assemblyPath -Algorithm SHA256).Hash
    if ($ExpectedAssemblyHashes.ContainsKey($name) -and $actualHash -ne $ExpectedAssemblyHashes[$name]) {
        throw "Benchmark family identity mismatch for ${name}: expected $($ExpectedAssemblyHashes[$name]), actual $actualHash."
    }
    Write-Host "FamilyAssembly=$assemblyPath SHA256=$actualHash"
}
foreach ($name in $ExpectedAssemblyHashes.Keys) {
    if ($name -notin @('CopperScreen.Benchmarks.dll', 'CopperScreen.dll', 'CopperMod.Amiga.dll', 'Copper68k.dll', 'CopperMod.Amiga.Emulator.dll')) {
        throw "Unknown expected assembly identity: $name"
    }
}

$allCpuSets = @([CpuSetProbe]::Read())
if (@($allCpuSets | Where-Object Group -ne 0).Count) {
    throw 'G6 performance INVALID / RERUN: multi-group processor telemetry mapping is not supported.'
}
$cpuSets = $allCpuSets
$selectedCpu = $cpuSets | Where-Object { $_.LogicalProcessorIndex -eq $LogicalProcessor } | Select-Object -First 1
if ($null -eq $selectedCpu) { throw "Logical CPU $LogicalProcessor was not reported by Windows CPU sets." }
if ($selectedCpu.EfficiencyClass -ne $ExpectedEfficiencyClass) {
    throw "Logical CPU $LogicalProcessor efficiency class is $($selectedCpu.EfficiencyClass), expected $ExpectedEfficiencyClass."
}
$protectedLogicalProcessors = @($cpuSets | Where-Object { $_.CoreIndex -eq $selectedCpu.CoreIndex } | ForEach-Object LogicalProcessorIndex)
$script:protectedAffinityMask = [int64]0
foreach ($processor in $protectedLogicalProcessors) { $script:protectedAffinityMask = $script:protectedAffinityMask -bor ([int64]1 -shl $processor) }
$powerPlan = (powercfg /getactivescheme) -join " "
$hashStream = [IO.File]::OpenRead($benchmarkAssembly)
$sha256 = [Security.Cryptography.SHA256]::Create()
try {
    $assemblyHash = [BitConverter]::ToString($sha256.ComputeHash($hashStream)).Replace("-", "")
}
finally {
    $sha256.Dispose()
    $hashStream.Dispose()
}
Write-Host "G6 controlled performance: CPU=$LogicalProcessor mask=$affinityMask core=$($selectedCpu.CoreIndex) siblings=$($protectedLogicalProcessors -join ',') protectedMask=$script:protectedAffinityMask efficiency=$($selectedCpu.EfficiencyClass) priority=Normal"
Write-Host "PowerPlan=$powerPlan"
Write-Host "Assembly=$benchmarkAssembly SHA256=$assemblyHash"
Write-Host "Warmup=$WarmupFrames Measured=$MeasuredFrames SamplesPerMode=$SamplesPerMode Threshold=$MinimumCandidateFps FPS MaxSpread=$MaximumSpreadPercent%"
Write-Host "HostPolicy=v2 telemetry=native-accounting coreOther=$CompetingCorePercent% packageOther=$CompetingPackagePercent% sustained=$SustainedContentionSeconds seconds; normal background apps permitted; CPU-load proxy, no thermal-sensor claim"

if ($CooldownSeconds -gt 0) {
    Write-Host "Cooldown: $CooldownSeconds second(s)."
    Start-Sleep -Seconds $CooldownSeconds
}
Assert-CleanPreflight

$formalOrder = @("slot-kernel", "legacy", "legacy", "slot-kernel", "slot-kernel", "legacy")
$order = if ($SamplesPerMode -eq 3) {
    $formalOrder
} else {
    $items = [Collections.Generic.List[string]]::new()
    for ($index = 0; $index -lt $SamplesPerMode; $index++) { $items.Add("slot-kernel"); $items.Add("legacy") }
    $items.ToArray()
}
$ordinals = @{ "slot-kernel" = 0; "legacy" = 0 }
$results = [Collections.Generic.List[object]]::new()
foreach ($mode in $order) {
    $ordinals[$mode]++
    Write-Host "Running $mode sample $($ordinals[$mode])/$SamplesPerMode."
    $sample = Invoke-ControlledSample -Mode $mode -Ordinal $ordinals[$mode]
    $results.Add($sample)
    Write-Host ("RESULT mode={0} sample={1} fps={2:F1} framebuffer={3} audio={4} disk={5} allocated={6}" -f $sample.Mode, $sample.Ordinal, $sample.Fps, $sample.Framebuffer, $sample.Audio, $sample.Disk, $sample.AllocatedBytes)
}

foreach ($mode in @("slot-kernel", "legacy")) {
    $modeResults = @($results | Where-Object Mode -eq $mode)
    $fingerprints = @($modeResults | ForEach-Object { "$($_.Framebuffer)|$($_.Audio)|$($_.Disk)|$($_.AllocatedBytes)|$($_.Status)" } | Select-Object -Unique)
    if ($fingerprints.Count -ne 1) { throw "G6 performance STOP: $mode correctness/allocation fingerprints differ across samples." }
    $values = @($modeResults | ForEach-Object Fps | Sort-Object)
    $median = if ($values.Count % 2 -eq 1) { $values[[int][Math]::Floor($values.Count / 2)] } else { ($values[$values.Count / 2 - 1] + $values[$values.Count / 2]) / 2.0 }
    $spreadPercent = 100.0 * ($values[-1] - $values[0]) / $median
    Write-Host ("SUMMARY mode={0} samples={1} median={2:F1} spread={3:F1}%" -f $mode, ($values -join ","), $median, $spreadPercent)
    if (-not $Quick -and $spreadPercent -gt $MaximumSpreadPercent) { throw "G6 performance series INVALID / RERUN: $mode spread is $spreadPercent%." }
    if ($mode -eq "slot-kernel") { $candidateMedian = $median }
}

# Validate both modes before applying the candidate throughput threshold.
# A low candidate must not hide an invalid reference series or its summary.
if (-not $Quick -and $candidateMedian -lt $MinimumCandidateFps) {
    throw "G6 performance STOP: candidate median $candidateMedian FPS is below $MinimumCandidateFps FPS."
}

if ($Quick) { Write-Host "G6 controlled performance runner QUICK PASS; no formal performance claim." }
else { Write-Host "G6 controlled performance PASS; this is no-cutover evidence only." }

# CopperScreen Headless Test Runner Plan

Status: **Initial runnable implementation complete**  
Created: 2026-08-03  
Primary target: deterministic CopperSharp68k test execution on A500 PAL OCS / `AccurateM68000`  
Secondary targets: OCS NTSC, ECS PAL/NTSC, MC68020/030/040 interpreter profiles, and JIT profiles where cycle-exact assertions are not required

## Implementation status — 2026-08-03

The first usable vertical slice is implemented:

- [x] Public `CopperScreen.Headless` class library with no CopperScreen,
      Avalonia, Miniaudio, or CopperPad dependency.
- [x] Synchronous runner with typed machine/CPU selection, bounded frame,
      cycle, and instruction execution, immutable register snapshots, and
      stable stop reasons.
- [x] Direct byte-based HUNK loading through the existing
      `AmigaHunkProgramLoader` and DOS return sentinel.
- [x] Public `IM68kCore` and `IM68kBus` access without exposing `Machine`.
- [x] `CopperScreen.Headless.Cli` with human/JSON output, expected-D0 checking,
      deterministic limits, and documented exit codes 0–3.
- [x] Five focused tests covering D0 return, exact instruction limiting,
      malformed HUNK rejection, snapshot isolation, and forbidden UI/audio
      dependencies.
- [x] All three projects registered in `CopperMod.sln`.

Still planned: richer chipset/media diagnostics, framebuffer rendering,
desktop orchestration extraction/parity tests, CLI file output/JUnit/Ctrl+C,
and a selected CopperSharp68k fixture shard. The API is already sufficient for
a caller to pass `M68kCompilationResult.Image` and assert the returned D0.

## Purpose

Create a UI-independent CopperScreen host that can boot and execute Amiga test
media synchronously from .NET tests and CI. Deliver both:

1. A public `CopperScreen.Headless` library API for in-process test control.
2. A thin `CopperScreen.Headless.Cli` console adapter for scripts and CI jobs.

The implementation must reuse CopperScreen's current machine construction,
boot lifecycle, and canonical frame-boundary scheduler. It must not introduce a
second, simplified execution loop whose CPU/custom-chip ordering can drift from
the desktop application.

## Current position

- `CopperScreenEmulator` already supports synchronous creation and
  `RenderNextFrame()` without launching Avalonia.
- `CopperScreenRuntime` adds the desktop thread, audio pacing, presentation
  queue, and host timing. Those responsibilities are not suitable for
  deterministic tests.
- `CopperScreenEmulator`, startup/profile types, CPU snapshots, and runtime
  state are internal to the Avalonia `CopperScreen` executable.
- `CopperScreen.Tests` frequently reaches the private `_machine` field through
  reflection. This demonstrates a missing test boundary and should be reduced
  as the new API becomes capable enough.
- `CopperScreen.csproj` references Avalonia, Miniaudio, and CopperPad. A test
  consumer should not need those packages merely to run emulation.
- CopperSharp68k's current `CompilerExecutionTests` are CPU-only tests. They do
  not boot an Amiga or use a guest mailbox. They copy `M68kCompilationResult.Code`
  to `0x0001_0000`, apply `Relocations`, initialize SP at `0x0008_0000`, place
  a return sentinel at `0x0000_1000`, execute at most 200,000 instructions, and
  compare D0 after PC reaches the sentinel.
- Those CPU-only tests already use `M68kCoreFactory` and a flat `TestBus`. They
  should remain the fast compiler-semantic gate; routing them all through a
  complete Amiga would change their purpose and cycle expectations.
- The new cross-project gate should consume `M68kCompilationResult.Image`, the
  real Amiga HUNK container, and validate CopperSharp output through
  CopperScreen's existing `AmigaHunkProgramLoader` and CopperStart application
  environment.
- CopperScreen already launches HUNK tools through
  `AmigaBootController.TryLaunchProgram`. It calls `BeginSubroutine`, uses the
  existing DOS return boundary at `0x00FF_FFFC`, and leaves the program's D0
  return value available when the boot instruction boundary completes.

## Non-negotiable invariants

1. Headless and desktop execution use the same boot and execution-boundary
   implementation.
2. CPU, DMA, Copper, blitter, Paula, CIA, disk, interrupt, and display events
   remain ordered in the scheduler's canonical integer cycle timebase.
3. `RunFrame(renderPresentation: false)` may skip host framebuffer composition,
   but it must not skip hardware work or alter CPU-visible timing.
4. No wall-clock time, audio queue depth, host thread scheduling, or Avalonia
   dispatcher state may affect a headless test result.
5. Every unbounded-looking operation has an explicit frame, cycle, or
   instruction limit and reports why it stopped.
6. A500 PAL OCS is the initial conformance profile. Other profiles must be
   selected explicitly and retain their own chipset/video geometry.
7. MC68000 reset state remains hardware-like: SR `0x2700`. Tests needing a
   lower interrupt mask must set it deliberately.
8. The public API exposes stable Copper68k contracts (`IM68kCore`, `IM68kBus`,
   state/value types) rather than private JIT, scheduler, or machine internals.
9. External code must not receive the mutable internal `Machine` object.
10. Existing desktop startup, input, audio, rendering, and profile behavior
    remains unchanged after extraction.

## Target project structure

```text
CopperScreen.Headless/
  CopperScreen.Headless.csproj       UI-independent class library
  CopperScreenTestRunner.cs          public session API
  CopperScreenTestOptions.cs         typed configuration
  CopperScreenTestSnapshot.cs        immutable diagnostics
  CopperScreenTestRunResult.cs       stop reason and final state
  CopperScreenGuestTestProtocol.cs   optional guest mailbox adapter
  Internal/                          extracted boot/frame orchestration

CopperScreen.Headless.Cli/
  CopperScreen.Headless.Cli.csproj   console executable
  Program.cs                         parsing, execution, result serialization

CopperScreen.Headless.Tests/
  CopperScreen.Headless.Tests.csproj focused public-contract tests

CopperScreen/
  ...                                Avalonia desktop adapter and presentation
```

Dependency direction:

```text
Copper68k
   ^
CopperMod.Amiga <- CopperMod.Amiga.Emulator
                         ^
                 CopperScreen.Headless
                    ^             ^
              CopperScreen   CopperScreen.Headless.Cli
```

`CopperScreen.Headless` must not reference `CopperScreen`, Avalonia,
Miniaudio-CS, CopperPad, or CopperPad.HidSharp. The desktop project should
reference the headless library after the shared orchestration is extracted.

## Proposed public API

The first public contract should remain small:

```csharp
public sealed class CopperScreenTestRunner : IDisposable
{
    public static CopperScreenTestRunner Create(CopperScreenTestOptions options);

    public IM68kCore Cpu { get; }
    public IM68kBus Bus { get; }
    public ReadOnlyMemory<int> Framebuffer { get; }
    public long FramesExecuted { get; }

    public CopperScreenTestSnapshot CaptureSnapshot();
    public CopperScreenProgramLaunchResult LaunchHunk(
        ReadOnlyMemory<byte> hunkImage,
        CopperScreenProgramLaunchOptions? options = null);
    public CopperScreenTestSnapshot RunFrame(bool renderPresentation = false);
    public CopperScreenTestRunResult RunUntil(
        Func<CopperScreenTestSnapshot, bool> stop,
        CopperScreenTestRunLimits limits,
        bool renderPresentation = false);
}
```

`LaunchHunk` is the primary CopperSharp68k integration boundary. It accepts
`M68kCompilationResult.Image`, not `Code`; HUNK parsing, segment allocation,
relocation, stack setup, application arguments, Exec base setup, and the
`0x00FF_FFFC` DOS return sentinel remain owned by CopperScreen's existing
program loader and boot controller.

Supporting types:

```csharp
public sealed record CopperScreenTestOptions(
    string BaseDirectory,
    string Profile,
    IReadOnlyList<string?> FloppyDisks,
    string? KickstartRom,
    IReadOnlyList<CopperScreenTestHardfile> Hardfiles,
    M68kBackendKind? CpuBackend = null);

public readonly record struct CopperScreenTestRunLimits(
    long MaxFrames,
    long? MaxCycles = null,
    long? MaxInstructions = null,
    bool StopOnCpuHalt = true);

public enum CopperScreenTestStopReason
{
    ConditionSatisfied,
    FrameLimitReached,
    CycleLimitReached,
    InstructionLimitReached,
    CpuHalted,
    StartupFailed,
    ProgramReturned
}
```

Snapshots should include at least:

- Runner frame count and emulated frame number.
- CPU cycles/native cycles, PC, last PC/opcode, SR, USP/SSP, D0-D7, A0-A7,
  stopped/halted state, and 020+/040 control state when applicable.
- Beam line and horizontal position.
- Profile, chipset, video standard, CPU backend, Chip RAM and Fast RAM sizes.
- DMACON, INTENA, INTREQ, BPLCON*, DIW*, DDF*, bitplane pointers/modulos,
  Copper PC/state, blitter state, sprite state, disk DMA state, and CIA
  ports/timers when requested through a diagnostics level.
- Inserted media identities and drive state.
- Stable status/error text.

Do not expose diagnostic arrays backed by mutable emulator storage. Copy them
or return immutable value objects.

## Configuration rules

- Prefer typed `CopperScreenTestOptions` for library consumers.
- Provide a compatibility factory that parses existing CopperScreen arguments
  so desktop profiles and current scripts continue to work.
- Resolve relative ROM, profile, ADF/IPF/ZIP, and HDF paths against the explicit
  `BaseDirectory`, never the process current directory.
- Default to A500 PAL OCS and `AccurateM68000` only when the caller does not
  select a profile.
- Record the resolved Agnus model, Denise model, PAL/NTSC mode, CPU, memory,
  Kickstart source, and media in every run result.
- Never silently reinterpret PAL frame counts for NTSC or ECS/AGA profiles.

## CopperSharp68k execution contract

There are two deliberately separate validation layers.

### Layer A — Existing CPU-only compiler tests

Keep `CompilerExecutionTests` on `M68kCoreFactory` plus `TestBus`. They are
designed to validate generated instruction semantics cheaply and precisely:

- Load address: `0x0001_0000`.
- Initial SP: `0x0008_0000`.
- Return sentinel: `0x0000_1000`.
- Completion: PC equals the sentinel.
- Result: D0.
- Limit: 200,000 instructions.
- Relocations: add the HUNK load address to every linker relocation.

Do not replace this layer with CopperScreen. It supports per-instruction hooks,
custom host gateways, arbitrary initial CPU state, and flat-memory assumptions
that are intentionally outside a real Amiga application's contract.

### Layer B — New Amiga HUNK integration tests

Compile selected fixtures with `AmigaM68kCompiler`,
`M68kOutputFormat.Hunk`, and `M68kRuntimeProfile.Application`. Pass
`M68kCompilationResult.Image` directly to `CopperScreenTestRunner.LaunchHunk`.

The runner must:

1. Start a CopperStart application-capable session without requiring an ADF.
2. Load the HUNK bytes using the existing `AmigaHunkProgramLoader`.
3. Reuse the existing program-memory allocator and register-frame setup.
4. Begin the subroutine using CopperScreen's program stack and DOS return
   address `0x00FF_FFFC`.
5. Set D0/A0 application arguments and A6 to the active Exec base exactly as
   the CopperBench path does.
6. Execute only through canonical outer scheduler boundaries.
7. Report `ProgramReturned` when the existing boot boundary recognizes the DOS
   sentinel, preserving D0 and the full final CPU snapshot.

Initial integration fixtures must be pure application cases that do not depend
on `TestBus.RegisterGateway`, `beforeInstruction`, custom `initialize` hooks, or
specific flat-memory addresses. Build an explicit portability manifest rather
than silently skipping incompatible cases.

Tests requiring AllocMem, Amiga SDK calls, exceptions, managed runtime support,
or other platform imports should be added incrementally after the basic D0
return corpus passes. Their expected environment must be the CopperStart host
services, not TestBus gateway emulation.

No mailbox protocol is required for the current CopperSharp68k suite. Add one
later only if long-running guest-side test bundles need multiple results from a
single process; keep it as an optional adapter outside the core runner.

## CLI contract

Initial command shape:

```text
dotnet run --project CopperScreen.Headless.Cli -- \
  --profile a500-ocs-pal \
  --hunk compiled-test \
  --max-frames 3000 \
  --result-json artifacts/coppersharp68k-result.json
```

Required options:

- `--profile <id-or-json>`
- `--hunk <path>` for a CopperSharp application image
- `--disk <path>` and indexed drive variants when needed
- `--kickstart-rom <path>`
- `--hdf <path>` / `--hdf-readonly <path>`
- `--cpu <backend>`
- `--max-frames <n>`
- `--max-cycles <n>`
- `--max-instructions <n>`
- `--until-pc <hex>` for generic bring-up
- `--result-json <path>`
- `--junit <path>` after the guest protocol is known
- `--render` only when framebuffer output is required

Exit codes:

- `0`: requested stop condition or guest pass.
- `1`: invalid arguments, profile/media/startup failure, or host exception.
- `2`: deterministic limit reached before success.
- `3`: program returned an unexpected result.
- `4`: unexpected CPU halt.

Human-readable progress goes to stderr when structured JSON is written to
stdout. Result objects and exit codes must be stable enough for CI scripts.

## Stage 0 — Freeze behavior and dependency boundaries

Goal: establish evidence before moving code.

### Work

- [ ] Record `git status --short` and preserve all unrelated user changes.
- [ ] Record the current focused CopperScreen test result.
- [ ] Add architecture tests proving the intended forbidden dependencies.
- [ ] Add characterization tests around `CopperScreenEmulator.Create`, reset,
      no-disk behavior, one-frame execution, boot failure, and presentation-off
      execution.
- [ ] Add a parity fixture that captures CPU state, beam position, drive state,
      framebuffer checksum, and audio checksum for a small deterministic run.
- [ ] Inventory the exact non-UI source dependency closure of
      `CopperScreenEmulator`.
- [ ] Identify every Avalonia type reachable from startup/profile/input and
      presentation geometry types.

### Exit gate

- [ ] Baseline tests and checksums are recorded.
- [ ] The extraction file list and dependency direction are documented.
- [ ] No production source has moved yet.

## Stage 1 — Define and test the public contract in place

Goal: make API semantics executable before project extraction.

### Work

- [ ] Add `CopperScreenTestRunner`, options, limits, snapshots, results, and
      stop-reason types beside the existing emulator initially.
- [ ] Wrap `CopperScreenEmulator`; do not duplicate its frame loop.
- [ ] Add an internal read-only machine access point only for the facade.
- [ ] Expose `IM68kCore` and `IM68kBus`, not `Machine`, `AmigaBus`, JIT classes,
      or execution scheduler internals.
- [ ] Make `RunUntil` evaluate the predicate before the first frame and after
      every completed boundary.
- [ ] Enforce positive deterministic limits and checked cycle/instruction
      deltas.
- [ ] Make disposal idempotent and reject all operations after disposal.
- [ ] Document that direct bus reads may have device side effects; provide a
      separate snapshot/probe API for non-mutating diagnostics.

### Tests

- [ ] Initial predicate can stop with zero frames executed.
- [ ] Exact frame/cycle/instruction limits select the expected stop reason.
- [ ] CPU halt behavior is configurable and deterministic.
- [ ] Snapshot register arrays cannot mutate live CPU state.
- [ ] Runner creation does not initialize Avalonia, Miniaudio, or CopperPad.
- [ ] Presentation-off and presentation-on runs have identical CPU, bus, disk,
      audio, and interrupt state at the same boundary.
- [ ] Invalid profiles and missing media return structured startup failures.

### Exit gate

- [ ] Public contract tests pass while the desktop still uses its original
      code path.
- [ ] API review confirms no unstable internal type leaks.

## Stage 2 — Extract the UI-independent library

Goal: produce `CopperScreen.Headless.dll` with no desktop dependencies.

### Work

- [ ] Create `CopperScreen.Headless/CopperScreen.Headless.csproj` targeting
      `net10.0`.
- [ ] Reference only `Copper68k`, `CopperMod.Amiga`,
      `CopperMod.Amiga.Emulator`, `CopperMod.Amiga.CyberGraphics`, and
      media libraries actually required by the extracted path.
- [ ] Move the test runner and shared orchestration into the new project.
- [ ] Move or split startup/profile/media types needed by both hosts.
- [ ] Split `CopperScreenInputOptions`: keep guest port/action configuration in
      the headless library and Avalonia `Key`/`PhysicalKey` mapping in the
      desktop project.
- [ ] Split presentation geometry into primitive, UI-neutral values; keep
      Avalonia `Point`, `Rect`, `Size`, and rendering conversions in the
      desktop adapter.
- [ ] Keep Miniaudio output, floppy host sound playback, window input,
      clipboard platform integration, and presentation queues in
      `CopperScreen`.
- [ ] Update `CopperScreen` to consume the extracted session.
- [ ] Remove duplicate source from the desktop assembly after parity is green.
- [ ] Add the project to `CopperMod.sln` with standard Debug/Release platform
      mappings.

### Architecture tests

- [ ] `CopperScreen.Headless` references no assembly whose name begins with
      `Avalonia`.
- [ ] It references neither `Miniaudio` nor `CopperPad`.
- [ ] `CopperScreen` references `CopperScreen.Headless`.
- [ ] `CopperScreen.Headless` does not reference `CopperScreen`.
- [ ] Public API reflection test finds no public return/parameter/property type
      from forbidden desktop or private implementation namespaces.

### Exit gate

- [ ] Stage 0 checksums match before and after extraction.
- [ ] Existing CopperScreen tests pass without reflection for capabilities now
      present in the public facade.
- [ ] Desktop startup and one representative interactive smoke test work.

## Stage 3 — Add the console adapter

Goal: make the runner usable from scripts and CI.

### Work

- [ ] Create `CopperScreen.Headless.Cli` as a console project referencing only
      `CopperScreen.Headless`.
- [ ] Implement strict option parsing and useful `--help` output.
- [ ] Support existing profile/media argument aliases where unambiguous.
- [ ] Emit deterministic JSON with schema version, resolved configuration,
      stop reason, elapsed host time, emulated limits, and final snapshot.
- [ ] Implement documented exit codes.
- [ ] Handle Ctrl+C by requesting cancellation at the next completed outer
      boundary; never interrupt the emulator mid-device update.
- [ ] Avoid changing process priority or GC latency mode.
- [ ] Add the project to the solution.

### Tests

- [ ] Help and invalid option tests.
- [ ] One-frame no-disk JSON golden test.
- [ ] `--until-pc` success and limit-reached tests.
- [ ] Missing ROM/media produces exit code 1 and structured diagnostics.
- [ ] CLI assembly has no direct Avalonia/Miniaudio/CopperPad reference.

### Exit gate

- [ ] CLI runs successfully on a clean machine without a desktop session.
- [ ] JSON output is parseable and stable under redirected stdout/stderr.

## Stage 4 — Integrate CopperSharp68k HUNK execution

Goal: preserve the existing fast CPU-only suite and add a real-Amiga
application integration layer over CopperScreen.

### Work

- [ ] Keep `CompilerExecutionTests.Execute` and `TestBus` unchanged as the
      CPU-only semantic and cycle gate.
- [ ] Add a public byte-based HUNK launch overload beneath the current
      disk-path-based `TryLaunchProgram`; both paths must share one launch core.
- [ ] Add `CopperScreenTestRunner.LaunchHunk` and expose program entry address,
      stack, arguments, start cycle, and launch diagnostics.
- [ ] Detect completion through the existing DOS program-return boundary at
      `0x00FF_FFFC`; do not poll an invented mailbox.
- [ ] Capture D0 before any startup-sequence continuation can replace the
      returned program context.
- [ ] Create a CopperSharp fixture portability manifest with exclusion reasons
      for TestBus gateways, instruction hooks, custom state initialization,
      fixed flat-memory assumptions, unsupported imports, and CPU models.
- [ ] Add a separate CopperSharp Amiga-integration test project or category
      that compiles selected entries and passes `M68kCompilationResult.Image`
      to the headless runner.
- [ ] Recreate the machine for each integration case initially. Optimize reuse
      only after reset/isolation parity tests exist.
- [ ] Start with MC68000 output on A500 PAL OCS / `AccurateM68000`.
- [ ] Add MC68020 and MC68040 profiles separately. CopperSharp currently runs
      MC68020, MC68040, and MC68060 compiler output on the Copper68k MC68040
      core for architectural compatibility; do not describe that as exact
      hardware timing, and do not claim MC68060 machine support.
- [ ] Capture failure diagnostics: full CPU state, bounded stack/disassembly,
      beam position, custom registers, Copper/blitter/disk/CIA state, and recent
      bus trace when explicitly enabled.
- [ ] Emit per-case JSON and optional JUnit XML.
- [ ] Distinguish unexpected D0, frame/cycle/instruction limit, CPU halt,
      emulator exception, HUNK load failure, unresolved platform import, and
      unsupported profile.

### Tests

- [ ] Synthetic HUNK returns a known D0 value through `0x00FF_FFFC`.
- [ ] HUNK code/data/BSS allocation and `HUNK_RELOC32` match the compiler's
      linked expectations.
- [ ] Truncated, malformed, and unsupported-section HUNK images fail cleanly.
- [ ] Initial D0/A0/A6 and stack match CopperBench application semantics.
- [ ] Identical compile-and-run results across two consecutive fresh sessions.
- [ ] Interpreter/JIT comparison uses identical initial state and records that
      JIT max-speed timing is not cycle-exact.
- [ ] Shards cover every selected test exactly once.

### Exit gate

- [ ] A representative CopperSharp68k application-HUNK shard runs headlessly
      in CI while the existing CPU-only suite remains green.
- [ ] Every failure is attributable and reproducible with one CLI command.

## Stage 5 — Migrate tests and stabilize packaging

Goal: make the new boundary the normal supported path.

### Work

- [ ] Replace reflection-based `_machine` access in CopperScreen tests where
      the public runner provides equivalent behavior.
- [ ] Keep highly specialized internal timing tests in the owning core test
      assembly rather than bloating the public API.
- [ ] Add XML documentation and a README with in-process and CLI examples.
- [ ] Decide whether `CopperScreen.Headless` is repository-only or a NuGet
      package; do not publish accidentally.
- [ ] If packable, add package metadata, API compatibility checks, and a pack
      smoke test.
- [ ] Add CI jobs for focused runner tests and one bounded guest corpus shard.

### Exit gate

- [ ] No new reflection access to `CopperScreenEmulator._machine` is permitted.
- [ ] Public API compatibility is checked in CI.
- [ ] Headless and desktop parity tests remain green.

## Verification commands

Run from the repository root, focused first:

```powershell
dotnet test .\CopperScreen.Headless.Tests\CopperScreen.Headless.Tests.csproj
dotnet test .\CopperScreen.Tests\CopperScreen.Tests.csproj --filter "TestRunner|Headless|Architecture|Boot|PresentationFrame"
dotnet test .\CopperMod.Amiga.Tests\CopperMod.Amiga.Tests.csproj --filter "M68k|M68020|M68040"
dotnet test .\CopperMod.Amiga.Tests\CopperMod.Amiga.Tests.csproj --filter "Display|Sprite|Copper|Blitter|BusTiming|Raster"
dotnet build .\CopperMod.sln --no-restore
```

After any shared scheduler, bus, DMA, boot, or register change:

```powershell
dotnet test .\CopperMod.Amiga.Tests\CopperMod.Amiga.Tests.csproj
```

CLI smoke test:

```powershell
dotnet run --project .\CopperScreen.Headless.Cli\CopperScreen.Headless.Cli.csproj -- \
  --profile vanilla-copperstart \
  --max-frames 1 \
  --result-json .\artifacts\headless-smoke.json
```

Use `repowise distill <command>` for noisy solution builds and broad test runs.

## Performance and determinism checks

- Compare headless runs using emulated cycles/frames, never host milliseconds.
- Record host time only as performance metadata.
- Run at least two identical invocations and compare final CPU state, beam,
  memory result, disk state, framebuffer checksum when rendered, and audio
  checksum.
- Verify steady-state presentation-off execution does not allocate per frame
  beyond existing unavoidable behavior.
- Do not introduce polling sleeps. The in-process runner is synchronous.
- Parallel corpus shards must use separate runner instances and separate
  writable media copies.

## Rollback strategy

- Stage 1 is additive and can be removed without changing emulator behavior.
- During Stage 2, keep each source move mechanical and preserve a working
  desktop adapter at every commit.
- If parity fails, restore the desktop to the pre-extraction orchestration and
  keep the characterization tests; do not compensate with timing delays or
  profile-specific exceptions.
- The CLI and guest protocol are leaf projects and can be disabled without
  affecting desktop execution.

## Completion criteria

This improvement is complete when:

- `CopperScreen.Headless` is a public, UI-independent class library.
- `CopperScreen.Headless.Cli` can run a bounded test workload without a desktop
  session and return stable JSON/exit codes.
- CopperSharp68k tests can report pass/fail through a documented adapter.
- Selected CopperSharp68k application fixtures compile to HUNK `Image` bytes,
  return through CopperScreen's existing DOS sentinel, and expose D0 without an
  ADF or interactive CopperBench operation.
- Headless and desktop sessions produce matching emulated state at equivalent
  boundaries.
- Focused CPU, bus/timing, CopperScreen, architecture, and solution-build gates
  pass.
- Existing unrelated working-tree changes remain untouched.

## Decisions remaining before Stage 4

1. Which initial CopperSharp fixture subset is portable to a real CopperStart
   application without TestBus hooks or fixed flat-memory assumptions?
2. Should the cross-repository tests consume a local project reference, a
   locally packed prerelease NuGet package, or invoke the CLI with compiler
   output written to disk?
3. Should every integration case recreate the machine permanently, or may a
   proven full CopperStart reset become an optimization later?
4. Is MC68000/A500 PAL OCS the only authoritative first gate, with 020/040
   treated as later architecture-compatibility coverage?
5. Should `CopperScreen.Headless` be published as NuGet or remain a
   repository-internal public API initially?

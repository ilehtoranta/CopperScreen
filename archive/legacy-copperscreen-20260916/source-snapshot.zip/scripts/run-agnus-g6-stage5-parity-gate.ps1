param(
    [string]$Configuration = "Release",
    [int]$WarmupFrames = 600,
    [int]$MeasuredFrames = 1,
    [string]$Workload = "Lemmings SR",
    [string]$Profile = "expanded-kickstart13.json",
    [string]$KickstartRom = "D:\TestData\ROM\Kickstart_13.rom",
    [switch]$SkipLegacyRollbackSmoke,
    [switch]$QuietBenchmarks
)

$ErrorActionPreference = "Stop"
$repoRoot = Split-Path -Parent $PSScriptRoot
$benchmarkProject = Join-Path $repoRoot "CopperScreen.Benchmarks\CopperScreen.Benchmarks.csproj"
$benchmarkAssembly = Join-Path $repoRoot "CopperScreen.Benchmarks\bin\$Configuration\net10.0\CopperScreen.Benchmarks.dll"

function Invoke-G6Benchmark {
    param(
        [ValidateSet("stage5", "slot-kernel", "legacy")]
        [string]$Mode
    )

    $modeArguments = switch ($Mode) {
        "stage5" { @("--agnus-live-requester-stage", "5") }
        "slot-kernel" { @("--agnus-slot-kernel") }
        "legacy" { @("--agnus-legacy") }
    }
    $arguments = @(
        $benchmarkAssembly,
        "--only", $Workload,
        "--profile", $Profile,
        "--cpu", "accurateM68000",
        "--warmup", $WarmupFrames,
        "--frames", $MeasuredFrames,
        "--repeat", "1",
        "--hardware-specialization",
        "--skip-presentation",
        "--no-phase-profile",
        "--kickstart-rom", $KickstartRom
    ) + $modeArguments

    $previousErrorActionPreference = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        $output = & dotnet @arguments 2>&1
        $exitCode = $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $previousErrorActionPreference
    }
    if (-not $QuietBenchmarks) {
        $output | Out-Host
    }
    if ($exitCode -ne 0) {
        if ($QuietBenchmarks) {
            $output | Out-Host
        }
        throw "G6 $Mode benchmark failed with exit code $exitCode."
    }

    $lines = @($output | ForEach-Object { $_.ToString() })
    $configurationLine = $lines | Where-Object { $_.StartsWith("Warmup=") } | Select-Object -Last 1
    $headerLine = $lines | Where-Object { $_.StartsWith("name`tagnus`tbackend`t") } | Select-Object -Last 1
    $resultLine = $lines | Where-Object { $_.StartsWith("$Workload`t") } | Select-Object -Last 1
    if (-not $configurationLine -or -not $headerLine -or -not $resultLine) {
        throw "G6 $Mode benchmark did not emit a parseable result."
    }
    if ($Mode -eq "stage5" -and $configurationLine -notmatch "AgnusLiveRequesterStage=5") {
        throw "G6 Stage-5 reference did not activate requester stage 5."
    }
    if ($Mode -eq "slot-kernel" -and $configurationLine -notmatch "Agnus=SlotKernel") {
        throw "G6 candidate did not activate the slot kernel."
    }

    $headers = $headerLine -split "`t"
    $values = $resultLine -split "`t"
    if ($headers.Count -ne $values.Count) {
        throw "G6 $Mode result has $($values.Count) values for $($headers.Count) headers."
    }

    $result = @{}
    for ($index = 0; $index -lt $headers.Count; $index++) {
        $result[$headers[$index]] = $values[$index]
    }

    return $result
}

if (-not (Test-Path -LiteralPath $KickstartRom -PathType Leaf)) {
    throw "Kickstart ROM not found: $KickstartRom"
}

# The managed DLL is the gate input. Avoid rewriting the generic Windows
# apphost so an unrelated/stale benchmark process cannot block validation.
& dotnet build $benchmarkProject -c $Configuration --no-restore -p:UseAppHost=false
if ($LASTEXITCODE -ne 0) {
    throw "G6 Stage-5 parity build failed with exit code $LASTEXITCODE."
}
if (-not (Test-Path -LiteralPath $benchmarkAssembly -PathType Leaf)) {
    throw "G6 managed benchmark assembly not found: $benchmarkAssembly"
}

# This focused hardware-oracle set is mandatory before applying the single
# requester-scoped Stage-5 exception below. It proves that fixed sprite slots,
# the committed horizon, and Copper single-slot ownership remain intact.
$hardwareOracleFilter = @(
    "SlotKernelCpuCannotReuseCommittedFixedSpriteSlot",
    "SpriteDmaWordExactSlotReadsOnlyFixedSpriteSlot",
    "SpriteDmaWordExactSlotDoesNotSearchForwardFromWrongSlot",
    "HrmSlotEngineMakesCopperWaitForReservedSpriteSlot",
    "SlotKernelRejectsCpuCandidateBehindCommittedBitplaneHorizon",
    "SlotKernelExpansionWriteDeniedByRefreshUsesImmediateNextFreeSlot",
    "SlotKernelRejectsOccupiedCopperSlotButAllowsAdjacentBoundaryInstructionFetch",
    "SlotKernelInstructionFetchUsesAdjacentSlotAfterCopperGrant",
    "CpuChipReadsCrossSpriteFetchWithValueAndPointerParity"
) -join "|"
& dotnet test (Join-Path $repoRoot "CopperMod.Amiga.Tests\CopperMod.Amiga.Tests.csproj") `
    -c $Configuration --no-restore --filter $hardwareOracleFilter
if ($LASTEXITCODE -ne 0) {
    throw "G6 requester-scoped hardware oracle failed with exit code $LASTEXITCODE."
}

$stage5 = Invoke-G6Benchmark -Mode "stage5"
$candidate = Invoke-G6Benchmark -Mode "slot-kernel"
$legacy = if ($SkipLegacyRollbackSmoke) {
    $null
}
else {
    Invoke-G6Benchmark -Mode "legacy"
}

$parityKeys = @("framebuffer", "disk")
$mismatches = foreach ($key in $parityKeys) {
    $stage5Value = if ($key -eq "disk") {
        ($stage5[$key] -split ",sched=", 2)[0]
    }
    else {
        $stage5[$key]
    }
    $candidateValue = if ($key -eq "disk") {
        ($candidate[$key] -split ",sched=", 2)[0]
    }
    else {
        $candidate[$key]
    }
    if ($stage5Value -ne $candidateValue) {
        "${key}: stage5=$stage5Value; slot-kernel=$candidateValue"
    }
}
$stage5Audio = $stage5["audio"]
$candidateAudio = $candidate["audio"]
$approvedStage5Audio = "884/1729/0,1978/0x478686E5"
$approvedCandidateAudio = "884/1720/0,1987/0x8E0646E5"
$audioOracleDisposition = "exact"
if ($stage5Audio -ne $candidateAudio) {
    if ($stage5Audio -eq $approvedStage5Audio -and
        $candidateAudio -eq $approvedCandidateAudio) {
        $audioOracleDisposition = "approved-fixed-sprite-stage5-divergence"
    }
    else {
        $mismatches += "audio: stage5=$stage5Audio; slot-kernel=$candidateAudio"
    }
}
$stage5Status = ($stage5["status"] -split " \| ", 2)[0]
$candidateStatus = ($candidate["status"] -split " \| ", 2)[0]
$legacyStatus = if ($null -eq $legacy) {
    "skipped"
}
else {
    ($legacy["status"] -split " \| ", 2)[0]
}
if ($stage5Status -ne $candidateStatus) {
    $mismatches += "status: stage5=$stage5Status; slot-kernel=$candidateStatus"
}
if ($null -ne $legacy -and
    $legacyStatus -match "fault|halted|unsupported|error") {
    throw "G6 forced-legacy rollback smoke failed: $legacyStatus"
}

if ($mismatches.Count -ne 0) {
    $mismatches | ForEach-Object { Write-Host "G6 PARITY STOP: $_" }
    throw "G6 Stage-5-versus-slot-kernel parity STOP with $($mismatches.Count) mismatch(es)."
}

Write-Host "G6 Stage-5-versus-slot-kernel architectural checkpoint PASS"
Write-Host "G6 CPU, interrupt, and requester-scoped slot-ledger trace checkpoints remain mandatory."
Write-Host "status=$stage5Status"
Write-Host "rollback_status=$legacyStatus"
Write-Host "audio_oracle=$audioOracleDisposition"
Write-Host "audio_stage5=$stage5Audio"
Write-Host "audio_slot_kernel=$candidateAudio"
foreach ($key in $parityKeys) {
    $value = if ($key -eq "disk") {
        ($candidate[$key] -split ",sched=", 2)[0]
    }
    else {
        $candidate[$key]
    }
    Write-Host "$key=$value"
}
